﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class Item
    {
        public int Item_Id { get; set; }
        public string Item_Name { get; set; }
        public double Price { get; set; }
        //date of expiry
        public DateOnly date { get; set; }
        public string Description { get; set; }
    }
}
