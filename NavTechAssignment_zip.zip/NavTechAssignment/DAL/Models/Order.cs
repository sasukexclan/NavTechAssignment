﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class Order
    {
        public int Order_Id { get; set; }
        public int Cust_Id { get; set; }
        public string Cust_Name { get; set; }
        
    }
}
