﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class Payment
    {
        public int OrderId { get; set; } 
        public string Mode { get; set; }
        public double Paid { get; set; }
        public string Status { get; set; } 
        public double balance { get; set; }
    }
}
