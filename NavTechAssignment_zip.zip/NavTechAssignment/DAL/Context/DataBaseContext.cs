﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

//DB context file acts like bridge between our code and the database 

namespace DAL.Context
{
    public class DataBaseContext: DbContext
    {
        //This is DataBaseContext that uses DbContext and has all the DbSets 
        public DataBaseContext(DbContextOptions<DataBaseContext> options) : base(options)
        {

        }

        public DbSet<Customer>customers { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<Item> items { get; set; }
        public DbSet<Payment> Payments { get; set; }
    }
}
