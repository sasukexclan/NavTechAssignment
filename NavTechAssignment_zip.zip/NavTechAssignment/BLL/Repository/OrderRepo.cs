﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Models;
using DAL.Context;

namespace BLL.Repository.Model
{
    public class OrderRepo:IOrderRepo
    {
        DataBaseContext db;
        public OrderRepo(DataBaseContext _db)
        {
            db = _db;
        }

        //get order details 
         public IEnumerable<Order> GetAllOrders()
        {
            return db.orders.Select(x => x).ToList();
        }

        //add order
        public Order AddOrder(int CustId , string mode)
        {
            Payment payment = new Payment();
            Order order = new Order();

            db.orders.Add(order);
            db.SaveChanges();
            payment.OrderId = order.Order_Id;
            payment.Mode = mode;    
            if(mode=="COD")
            {
                payment.Status = "Pending";
                payment.Paid = 0.0;
            }

            else if(mode=="UPI")
            {
                payment.Status = "Completed";
                payment.balance = 0.0;
            }
            db.Payments.Add(payment);
            db.SaveChanges();
            return order;
        }

        //getting payment by id number 
        public Payment GetPaymentByOrderId(int id)
        {
            Payment payment = db.Payments.FirstOrDefault(p => p.OrderId == id);
            return payment;
        }

        //deleting order by id number 
        public Order DeleteOrderByOrderId(int id)
        {
            Payment payment = db.Payments.FirstOrDefault(p => p.OrderId == id);
            Order order = db.orders.FirstOrDefault(o => o.Order_Id == id);
            if (order != null)
            {
                db.Payments.Remove(payment);
                db.orders.Remove(order);
                db.SaveChanges();
            }
            return order;
        }

        Payment IOrderRepo.GetPaymentByOrderId()
        {
            throw new NotImplementedException();
        }
    }
}
