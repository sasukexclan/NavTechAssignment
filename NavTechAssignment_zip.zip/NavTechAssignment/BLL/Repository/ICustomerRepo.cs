﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Models;

namespace BLL.Repository
{
    public interface ICustomerRepo
    {
        public IEnumerable<Customer> GetAllCustomer(); //it will give the details of all the customers
        public Customer GetCustomerById(int id); //it will give the details of the customer with that particular id
        public IEnumerable<Customer> AddCustomer(IEnumerable<Customer> name); //add new customer
        public Customer DeleteCustomerById(int id);
        public Customer UpdateCustomerById(string name); //updates customer details by id

    }
}
