﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Context;
using DAL.Models;

namespace BLL.Repository.Model
{
    public class ItemRepo : IItem
    {
        DataBaseContext db;
        Item item;

        public ItemRepo(DataBaseContext _db)
        {
            db = _db;
            item = new Item();
        }

        //adding new item 
        public IEnumerable<Item>AddItem(IEnumerable<Item> items)
        {
            db.items.AddRange(items);
            db.SaveChanges();
            return items;
        }

        //deleting product by id
        public void deleteProductById(int id)
        {
            Item item = db.items.FirstOrDefault(c=>c.Item_Id==id);
            if (item!=null)
            {
                db.Remove(item);
                db.SaveChanges ();
            }
        }

        IEnumerable<ItemRepo> IItem.AddItem(string name)
        {
            throw new NotImplementedException();
        }
    }
}
