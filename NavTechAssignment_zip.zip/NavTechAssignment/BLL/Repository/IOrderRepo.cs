﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Models;


namespace BLL.Repository
{
    public interface IOrderRepo
    {
        public Order AddOrder(int CustId, string mode); 
        public IEnumerable<Order> GetAllOrders();//list of all the orders
        public Payment GetPaymentByOrderId();
        public Order DeleteOrderByOrderId(int id);

    }
}
