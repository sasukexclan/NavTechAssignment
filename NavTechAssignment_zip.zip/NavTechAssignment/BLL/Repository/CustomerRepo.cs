﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Models;
using DAL.Context;

namespace BLL.Repository.Model
{
    public class CustomerRepo:ICustomerRepo
    {
        DataBaseContext db;
        public CustomerRepo(DataBaseContext _db)
        {
            db = _db;
        }
        public IEnumerable<Customer> AddCustomer(IEnumerable<Customer> names)
        {
            db.customers.AddRange(names);
            db.SaveChanges();
            return names;
        }

        public Customer DeleteCustomerById(int id)
        {
           Customer customer = db.customers.SingleOrDefault(c => c.Cust_Id == id);
            if(customer!=null)
            {
                db.customers.Remove(customer);
                db.SaveChanges();
            }
            return customer;
        }

        public IEnumerable<Customer> GetAllCustomer()
        {
            return db.customers.Select(x => x).ToList();
        }

        public Customer GetCustomerById(int id)
        {
            return (db.customers.Find(id));
        }

        public Customer UpdateCustomerById(int id, string email)
        {
           
            var customer1 = db.customers.SingleOrDefault(c=>c.email == email);

            //we can also use remote attribute to check if there's an email which already exist. 

            if(customer1 != null)
            {
                db.Entry<Customer>(customer1).CurrentValues.SetValues(email);
                db.SaveChanges();
            }
            return customer1;
        }

        public Customer UpdateCustomerById(string name)
        {
            throw new NotImplementedException();
        }
    }
}
