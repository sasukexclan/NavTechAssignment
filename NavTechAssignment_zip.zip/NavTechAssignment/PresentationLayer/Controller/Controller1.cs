﻿using BLL;
using DAL;
using BLL.Repository;
using DAL.Models;
using DAL.Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Aardvark.Base;
using Order = DAL.Models.Order;

namespace PresentationLayer.Controller
{
    [Route("api/[Controller]")]
    [Produces("application/json")]
    [ApiController]
    public class Controller1:ControllerBase
    {
        IItem iit;
        IOrderRepo ior;
        ICustomerRepo icr;

        public readonly ILogger<Controller1> _logger;

        public Controller1(IItem _iit, IOrderRepo _ior , ICustomerRepo _icr, ILogger<Controller1> logger)
        {
            this.iit = _iit;
            this.ior = _ior;
            this.icr = _icr;
        }

        [HttpGet("GetCustomer")]
        public IEnumerable<Customer> GetAllCustomers()
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
                return icr.GetAllCustomer();
            }
            catch (Exception)
            {
                return Enumerable.Empty<Customer>();
            }

        }

        [HttpGet("GetCustomerById")]
        public Customer GetCustomerById(int id)
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
                return icr.GetCustomerById(id);
            }
            catch (Exception)
            {
                return null;
            }

        }
        [HttpGet("AddCustomer")]
        public Customer AddCustomer(IEnumerable<Customer> name)
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
               return (Customer)icr.AddCustomer(name);
                //will return a message that new customer has been updated
            }
            catch (Exception)
            {
                return null;
            }

        }

        [HttpPut("UpdateCustomerById")]
        public Customer UpdateCustomerById(string name)
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
                return icr.UpdateCustomerById(name);
                //will return a message that changes has been made in the existing data 
            }
            catch (Exception)
            {
                return null;
            }
        }

        //gives all the list of all the orders
        [HttpGet("GetOrder")]
        public Order GetAllOrders()
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
                return (Order)ior.GetAllOrders();
            }
            catch
            {
                return (Order)Enumerable.Empty<Order>();
            }

        }

        [HttpDelete("DeleteByOrderId")]
        public Order DeleteOrderByOrderId(int id)
        {
            _logger.LogInformation("Controller Excuting ....");
            try
            {
                return (Order)ior.DeleteOrderByOrderId(id);
            }
            catch
            {
                return (Order)Enumerable.Empty<Order>();
            }

        }

    }
}
